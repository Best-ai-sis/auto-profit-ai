# Конфигурация Telegram-бота
API_TOKEN = 'YOUR_TOKEN_HERE'